module.exports = {
    client: 'mysql',
    connection: {
        host: 'localhost',
        user: 'root',
        password: '',
        database: 'magnetic-grotto'
    },
    seeds: {
        directory: './seeds'
    },
    debug: true
  }